//
//  Playlist+CoreDataProperties.m
//  SoundCloudNew
//
//  Created by Trung Đức on 1/30/16.
//  Copyright © 2016 Trung Đức. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Playlist+CoreDataProperties.h"

@implementation Playlist (CoreDataProperties)

@dynamic artworkURL;
@dynamic index;
@dynamic title;
@dynamic createdAt;

@end
