//
//  MoreCell.h
//  SoundCloudNew
//
//  Created by Trung Đức on 1/30/16.
//  Copyright © 2016 Trung Đức. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblColor;

@end
